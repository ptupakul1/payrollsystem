package com.cg.payroll.main;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.services.PayrollServicesImpl;
public class MainClass {

	public static void main(String[] args) {
		PayrollServicesImpl payrollServicesImpl =new PayrollServicesImpl();
		int associateID=payrollServicesImpl.acceptAssociateDetails("siva", "prasad", "siva@gamil.com", "adm", "analyst", "dfsdfsfs",100000, 30000, 1000, 1000, 1234567, "hdfc", "hdsgc10025");
		associateID=payrollServicesImpl.calaculateNetSalary(associateID);
		Associate associate=payrollServicesImpl.getAssociateDetails(associateID);
		System.out.println(associate.getSalary().getGrossSalary());
		System.out.println(associate.getSalary().getMonthlyTax());
		System.out.println(associate.getSalary().getNetSalary());

	}

}

